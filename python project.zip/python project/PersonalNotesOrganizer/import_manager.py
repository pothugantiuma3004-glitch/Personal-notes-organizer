"""
import_manager.py - Bulk CSV Import and Data Ingestion Module
Validates, parses, and ingests external notes datasets into the system.
"""

import os
import csv
from typing import Dict, Any, List, Tuple
from notes_manager import NotesManager
from validation import validate_note_payload, sanitize_tags


class ImportManager:
    """Handles parsing and ingestion of external CSV notes datasets."""

    @classmethod
    def import_from_csv(cls,
                        filepath: str,
                        notes_manager: NotesManager,
                        skip_duplicate_titles: bool = True) -> Dict[str, Any]:
        """
        Imports notes from a CSV file into the provided NotesManager.
        Returns a summary report dictionary:
        {
            "success": bool,
            "total_rows": int,
            "imported": int,
            "skipped": int,
            "errors": List[str]
        }
        """
        if not os.path.exists(filepath):
            return {
                "success": False,
                "total_rows": 0,
                "imported": 0,
                "skipped": 0,
                "errors": [f"File not found: {filepath}"]
            }

        existing_titles = {n.get("title", "").strip().lower() for n in notes_manager.notes}
        imported_count = 0
        skipped_count = 0
        errors: List[str] = []
        total_rows = 0

        try:
            with open(filepath, "r", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                if not reader.fieldnames:
                    return {
                        "success": False,
                        "total_rows": 0,
                        "imported": 0,
                        "skipped": 0,
                        "errors": ["CSV file is empty or missing headers."]
                    }

                # Clean header names (strip spaces, lowercase)
                header_map = {col.strip().lower(): col for col in reader.fieldnames if col}

                if "title" not in header_map or "content" not in header_map:
                    return {
                        "success": False,
                        "total_rows": 0,
                        "imported": 0,
                        "skipped": 0,
                        "errors": ["CSV must at minimum contain 'title' and 'content' columns."]
                    }

                for row_idx, raw_row in enumerate(reader, start=2):
                    total_rows += 1
                    row = {k.strip().lower(): v for k, v in raw_row.items() if k}

                    title = (row.get("title") or "").strip()
                    content = (row.get("content") or "").strip()
                    category = (row.get("category") or "Personal").strip()
                    tags = row.get("tags") or ""
                    deadline = (row.get("deadline") or "").strip() or None
                    priority = (row.get("priority") or "Medium").strip().capitalize()
                    status = (row.get("status") or "Pending").strip().title()

                    # Check title duplication
                    if skip_duplicate_titles and title.lower() in existing_titles:
                        skipped_count += 1
                        continue

                    # Validate row payload
                    payload = {
                        "title": title,
                        "content": content,
                        "category": category,
                        "priority": priority,
                        "status": status,
                        "deadline": deadline
                    }
                    valid, errs = validate_note_payload(payload)
                    if not valid:
                        errors.append(f"Row {row_idx} ('{title[:20]}'): {', '.join(errs)}")
                        skipped_count += 1
                        continue

                    # Create note through notes manager
                    try:
                        notes_manager.create_note(
                            title=title,
                            content=content,
                            category=category,
                            tags=tags,
                            deadline=deadline,
                            priority=priority,
                            status=status
                        )
                        existing_titles.add(title.lower())
                        imported_count += 1
                    except Exception as ex:
                        errors.append(f"Row {row_idx}: {str(ex)}")
                        skipped_count += 1

        except Exception as e:
            return {
                "success": False,
                "total_rows": total_rows,
                "imported": imported_count,
                "skipped": skipped_count,
                "errors": [f"Error reading CSV: {e}"]
            }

        return {
            "success": True,
            "total_rows": total_rows,
            "imported": imported_count,
            "skipped": skipped_count,
            "errors": errors
        }
