"""
export_manager.py - Multi-Format Notes Export Engine
Exports notes to CSV, formatted TXT, and GitHub/Obsidian-compatible Markdown.
"""

import os
import csv
from datetime import datetime
from typing import List, Dict, Any

from storage import ensure_directory

DEFAULT_REPORTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "reports")


class ExportManager:
    """Handles multi-format reporting and file exporting."""

    @staticmethod
    def _default_filename(ext: str, prefix: str = "notes_export") -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        ensure_directory(DEFAULT_REPORTS_DIR)
        return os.path.join(DEFAULT_REPORTS_DIR, f"{prefix}_{timestamp}.{ext}")

    @classmethod
    def export_to_csv(cls, notes: List[Dict[str, Any]], filepath: str = None) -> str:
        """
        Exports notes to a standard CSV file with headers.
        Returns the saved file path.
        """
        path = filepath or cls._default_filename("csv")
        ensure_directory(path)

        fieldnames = ["id", "title", "content", "category", "tags", "priority", "status", "deadline", "created_at", "updated_at"]

        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for note in notes:
                row = dict(note)
                row["tags"] = ", ".join(note.get("tags", []))
                row["deadline"] = note.get("deadline") or ""
                writer.writerow(row)

        return os.path.abspath(path)

    @classmethod
    def export_to_txt(cls, notes: List[Dict[str, Any]], filepath: str = None) -> str:
        """
        Exports notes to a human-readable text document with formatted note cards.
        """
        path = filepath or cls._default_filename("txt")
        ensure_directory(path)

        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines = [
            "=======================================================================",
            "                      PERSONAL NOTES ARCHIVE REPORT                    ",
            f" Generated: {now_str} | Total Notes: {len(notes)}",
            "=======================================================================\n"
        ]

        for idx, note in enumerate(notes, 1):
            tags_str = ", ".join([f"#{t}" for t in note.get("tags", [])]) or "None"
            deadline_str = note.get("deadline") or "None"
            lines.extend([
                f"[{idx}] {note.get('title', 'Untitled')} ({note.get('id', 'N/A')})",
                f"    Category: {note.get('category', 'Uncategorized'):<15} Priority: {note.get('priority', 'Medium'):<10} Status: {note.get('status', 'Pending')}",
                f"    Deadline: {deadline_str:<15} Tags: {tags_str}",
                f"    Created:  {note.get('created_at', 'N/A')[:10]}        Updated: {note.get('updated_at', 'N/A')[:10]}",
                "    " + "-" * 65,
                "    Content:",
                "\n".join([f"      {line}" for line in note.get("content", "").splitlines()]),
                "\n" + "=" * 71 + "\n"
            ])

        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        return os.path.abspath(path)

    @classmethod
    def export_to_markdown(cls, notes: List[Dict[str, Any]], filepath: str = None) -> str:
        """
        Exports notes to Obsidian and GitHub Flavored Markdown format.
        """
        path = filepath or cls._default_filename("md")
        ensure_directory(path)

        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines = [
            "# Personal Notes Organizer - Export",
            "",
            f"> **Generated:** {now_str}  ",
            f"> **Total Notes:** {len(notes)}  ",
            "",
            "---",
            ""
        ]

        for note in notes:
            tags_str = " ".join([f"`#{t}`" for t in note.get("tags", [])]) or "_None_"
            deadline_str = note.get("deadline") or "_None_"
            lines.extend([
                f"## {note.get('title', 'Untitled')} (`{note.get('id')}`)",
                "",
                f"- **Category:** `{note.get('category')}`",
                f"- **Priority:** **{note.get('priority')}**",
                f"- **Status:** `{note.get('status')}`",
                f"- **Deadline:** {deadline_str}",
                f"- **Tags:** {tags_str}",
                f"- **Timestamps:** Created `{note.get('created_at', '')[:10]}` | Updated `{note.get('updated_at', '')[:10]}`",
                "",
                "### Content",
                "",
                note.get("content", ""),
                "",
                "---",
                ""
            ])

        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        return os.path.abspath(path)
