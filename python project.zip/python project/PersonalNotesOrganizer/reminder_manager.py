"""
reminder_manager.py - Deadline Tracking and Reminder Alerts System
Monitors due dates, identifies overdue tasks, and organizes upcoming priorities.
"""

from datetime import datetime, date
from typing import List, Dict, Any, Optional


class ReminderManager:
    """Calculates reminder states and urgency metrics for notes with deadlines."""

    @staticmethod
    def _parse_date(date_val: Any) -> Optional[date]:
        """Safely parses date into date object."""
        if not date_val:
            return None
        if isinstance(date_val, date) and not isinstance(date_val, datetime):
            return date_val
        if isinstance(date_val, datetime):
            return date_val.date()
        try:
            clean_str = str(date_val).strip()[:10]
            return datetime.strptime(clean_str, "%Y-%m-%d").date()
        except ValueError:
            return None

    @classmethod
    def evaluate_note(cls, note: Dict[str, Any], reference_date: Optional[date] = None) -> Dict[str, Any]:
        """
        Evaluates a single note's deadline urgency.
        Returns dictionary with keys: status, days_left, is_urgent, label.
        """
        ref_date = reference_date or date.today()
        deadline_raw = note.get("deadline")
        deadline = cls._parse_date(deadline_raw)
        status = note.get("status", "Pending")

        if not deadline:
            return {
                "status": "No Deadline",
                "days_left": None,
                "is_urgent": False,
                "label": "No Deadline"
            }

        if status == "Completed":
            return {
                "status": "Completed",
                "days_left": (deadline - ref_date).days,
                "is_urgent": False,
                "label": "Completed"
            }

        delta = (deadline - ref_date).days

        if delta < 0:
            return {
                "status": "Overdue",
                "days_left": delta,
                "is_urgent": True,
                "label": f"OVERDUE by {abs(delta)} day{'s' if abs(delta) != 1 else ''}"
            }
        elif delta == 0:
            return {
                "status": "Due Today",
                "days_left": 0,
                "is_urgent": True,
                "label": "DUE TODAY!"
            }
        elif delta <= 3:
            return {
                "status": "Urgent",
                "days_left": delta,
                "is_urgent": True,
                "label": f"Due in {delta} day{'s' if delta != 1 else ''}"
            }
        elif delta <= 7:
            return {
                "status": "Upcoming",
                "days_left": delta,
                "is_urgent": False,
                "label": f"Due in {delta} days"
            }
        else:
            return {
                "status": "Future",
                "days_left": delta,
                "is_urgent": False,
                "label": f"Due in {delta} days ({deadline})"
            }

    @classmethod
    def get_overdue_notes(cls, notes: List[Dict[str, Any]], reference_date: Optional[date] = None) -> List[Dict[str, Any]]:
        """Returns all uncompleted notes whose deadline is before reference date."""
        results = []
        for note in notes:
            eval_info = cls.evaluate_note(note, reference_date)
            if eval_info["status"] == "Overdue":
                decorated = dict(note)
                decorated["reminder_info"] = eval_info
                results.append(decorated)
        return sorted(results, key=lambda n: n["reminder_info"]["days_left"])

    @classmethod
    def get_due_today_notes(cls, notes: List[Dict[str, Any]], reference_date: Optional[date] = None) -> List[Dict[str, Any]]:
        """Returns uncompleted notes due on the reference date."""
        results = []
        for note in notes:
            eval_info = cls.evaluate_note(note, reference_date)
            if eval_info["status"] == "Due Today":
                decorated = dict(note)
                decorated["reminder_info"] = eval_info
                results.append(decorated)
        return results

    @classmethod
    def get_upcoming_notes(cls, notes: List[Dict[str, Any]], days: int = 7, reference_date: Optional[date] = None) -> List[Dict[str, Any]]:
        """Returns uncompleted notes due within the next N days."""
        results = []
        for note in notes:
            eval_info = cls.evaluate_note(note, reference_date)
            days_left = eval_info["days_left"]
            if days_left is not None and 0 < days_left <= days and note.get("status") != "Completed":
                decorated = dict(note)
                decorated["reminder_info"] = eval_info
                results.append(decorated)
        return sorted(results, key=lambda n: n["reminder_info"]["days_left"])

    @classmethod
    def get_reminders_summary(cls, notes: List[Dict[str, Any]], reference_date: Optional[date] = None) -> Dict[str, Any]:
        """Provides a statistical summary of all deadlines."""
        overdue = cls.get_overdue_notes(notes, reference_date)
        due_today = cls.get_due_today_notes(notes, reference_date)
        upcoming = cls.get_upcoming_notes(notes, days=7, reference_date=reference_date)

        return {
            "overdue_count": len(overdue),
            "due_today_count": len(due_today),
            "upcoming_count": len(upcoming),
            "overdue_notes": overdue,
            "due_today_notes": due_today,
            "upcoming_notes": upcoming,
            "has_urgent": len(overdue) > 0 or len(due_today) > 0
        }
