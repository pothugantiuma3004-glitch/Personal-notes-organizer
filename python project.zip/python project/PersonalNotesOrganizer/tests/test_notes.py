"""
test_notes.py - Comprehensive Unit Test Suite
Validates normal operations, boundary cases, invalid inputs, and error recovery.
"""

import os
import shutil
import tempfile
import unittest
from datetime import date, timedelta

# Import modules from parent directory
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from notes_manager import NotesManager
from search_manager import SearchManager
from reminder_manager import ReminderManager
from analytics import AnalyticsManager
from export_manager import ExportManager
from import_manager import ImportManager
from storage import load_notes, save_notes, create_backup
from validation import (
    validate_title,
    validate_content,
    validate_date,
    validate_priority,
    sanitize_tags
)


class BaseTestCase(unittest.TestCase):
    def setUp(self):
        """Create a temporary directory for isolated test databases."""
        self.test_dir = tempfile.mkdtemp()
        self.notes_path = os.path.join(self.test_dir, "notes.json")
        self.backup_path = os.path.join(self.test_dir, "backup.json")
        self.manager = NotesManager(filepath=self.notes_path, backup_path=self.backup_path)

    def tearDown(self):
        """Clean up temporary directory."""
        shutil.rmtree(self.test_dir, ignore_errors=True)


class TestValidation(unittest.TestCase):
    def test_validate_title(self):
        ok, _ = validate_title("Valid Title")
        self.assertTrue(ok)
        ok, msg = validate_title("   ")
        self.assertFalse(ok)
        ok, msg = validate_title("")
        self.assertFalse(ok)

    def test_validate_content(self):
        ok, _ = validate_content("Valid content body")
        self.assertTrue(ok)
        ok, _ = validate_content("   ")
        self.assertFalse(ok)

    def test_validate_date(self):
        self.assertTrue(validate_date("2026-11-25")[0])
        self.assertTrue(validate_date("")[0])
        self.assertTrue(validate_date(None)[0])
        self.assertFalse(validate_date("25-11-2026")[0])
        self.assertFalse(validate_date("invalid-date")[0])

    def test_validate_priority(self):
        self.assertTrue(validate_priority("High")[0])
        self.assertTrue(validate_priority("medium")[0])
        self.assertTrue(validate_priority("low")[0])
        self.assertFalse(validate_priority("Urgent")[0])

    def test_sanitize_tags(self):
        tags = sanitize_tags("#Python, #exam, python; study, , ")
        self.assertEqual(tags, ["exam", "python", "study"])


class TestNotesManager(BaseTestCase):
    def test_create_note_success(self):
        note = self.manager.create_note(
            title="Algorithms Midterm",
            content="Study sorting and dynamic programming.",
            category="College",
            tags=["exam", "cs"],
            deadline="2026-12-01",
            priority="High"
        )
        self.assertEqual(note["id"], "NOTE-001")
        self.assertEqual(note["title"], "Algorithms Midterm")
        self.assertEqual(note["category"], "College")
        self.assertEqual(note["priority"], "High")
        self.assertIn("exam", note["tags"])
        self.assertEqual(len(self.manager.notes), 1)

    def test_sequential_ids(self):
        n1 = self.manager.create_note("First", "Content 1")
        n2 = self.manager.create_note("Second", "Content 2")
        self.assertEqual(n1["id"], "NOTE-001")
        self.assertEqual(n2["id"], "NOTE-002")

    def test_create_note_invalid_title(self):
        with self.assertRaises(ValueError):
            self.manager.create_note(title="", content="Valid content")

    def test_update_note(self):
        note = self.manager.create_note("Initial Title", "Initial Content")
        updated = self.manager.update_note(note["id"], title="Updated Title", status="Completed")
        self.assertEqual(updated["title"], "Updated Title")
        self.assertEqual(updated["status"], "Completed")

    def test_delete_note(self):
        note = self.manager.create_note("To Delete", "Content")
        self.assertTrue(self.manager.delete_note(note["id"]))
        self.assertEqual(len(self.manager.notes), 0)
        self.assertFalse(self.manager.delete_note("NON-EXISTENT"))


class TestSearchManager(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.manager.create_note("Python Tutorial", "Learn basics of Python syntax", "Projects", ["python", "code"])
        self.manager.create_note("Grocery Shopping", "Milk, bread, eggs", "Personal", ["food", "home"], priority="Low")
        self.manager.create_note("Database Homework", "SQL queries and normalization", "College", ["sql", "exam"], priority="High")

    def test_keyword_search(self):
        results = SearchManager.search_by_keyword(self.manager.notes, "python")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["title"], "Python Tutorial")

    def test_filter_by_category(self):
        results = SearchManager.filter_by_category(self.manager.notes, "College")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["title"], "Database Homework")

    def test_filter_by_tag(self):
        results = SearchManager.filter_by_tag(self.manager.notes, "food")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["title"], "Grocery Shopping")

    def test_composite_search(self):
        results = SearchManager.composite_search(self.manager.notes, query="queries", category="College", priority="High")
        self.assertEqual(len(results), 1)


class TestReminderManager(unittest.TestCase):
    def test_deadline_status(self):
        today = date.today()
        yesterday = (today - timedelta(days=1)).strftime("%Y-%m-%d")
        tomorrow = (today + timedelta(days=1)).strftime("%Y-%m-%d")
        today_str = today.strftime("%Y-%m-%d")

        note_overdue = {"id": "1", "deadline": yesterday, "status": "Pending"}
        note_today = {"id": "2", "deadline": today_str, "status": "Pending"}
        note_upcoming = {"id": "3", "deadline": tomorrow, "status": "Pending"}
        note_done = {"id": "4", "deadline": yesterday, "status": "Completed"}

        self.assertEqual(ReminderManager.evaluate_note(note_overdue, today)["status"], "Overdue")
        self.assertEqual(ReminderManager.evaluate_note(note_today, today)["status"], "Due Today")
        self.assertEqual(ReminderManager.evaluate_note(note_upcoming, today)["status"], "Urgent")
        self.assertEqual(ReminderManager.evaluate_note(note_done, today)["status"], "Completed")


class TestStorageAndBackup(BaseTestCase):
    def test_backup_and_corrupt_recovery(self):
        # Save valid notes
        self.manager.create_note("Safe Note", "Original Content")
        create_backup(self.notes_path, self.backup_path)
        self.assertTrue(os.path.exists(self.notes_path))
        self.assertTrue(os.path.exists(self.backup_path))

        # Corrupt the primary notes.json intentionally
        with open(self.notes_path, "w", encoding="utf-8") as f:
            f.write("{ invalid json corrupted content ")

        # Loading should recover from backup
        recovered = load_notes(self.notes_path, self.backup_path)
        self.assertEqual(len(recovered), 1)
        self.assertEqual(recovered[0]["title"], "Safe Note")


class TestExportsAndImports(BaseTestCase):
    def test_exports(self):
        self.manager.create_note("Export Note", "Sample note body", "Projects", ["test"])
        reports_dir = os.path.join(self.test_dir, "reports")

        csv_file = os.path.join(reports_dir, "out.csv")
        txt_file = os.path.join(reports_dir, "out.txt")
        md_file = os.path.join(reports_dir, "out.md")

        p_csv = ExportManager.export_to_csv(self.manager.notes, csv_file)
        p_txt = ExportManager.export_to_txt(self.manager.notes, txt_file)
        p_md = ExportManager.export_to_markdown(self.manager.notes, md_file)

        self.assertTrue(os.path.exists(p_csv))
        self.assertTrue(os.path.exists(p_txt))
        self.assertTrue(os.path.exists(p_md))

    def test_csv_import(self):
        sample_csv = os.path.join(self.test_dir, "sample.csv")
        with open(sample_csv, "w", encoding="utf-8") as f:
            f.write("title,content,category,tags,priority,status,deadline\n")
            f.write("Import 1,Body 1,College,tag1,High,Pending,2026-12-10\n")
            f.write("Import 2,Body 2,Personal,tag2,Low,Completed,2026-12-15\n")

        res = ImportManager.import_from_csv(sample_csv, self.manager)
        self.assertTrue(res["success"])
        self.assertEqual(res["imported"], 2)
        self.assertEqual(len(self.manager.notes), 2)


class TestAnalytics(BaseTestCase):
    def test_metrics(self):
        self.manager.create_note("Note A", "Five words in this note", "College")
        self.manager.create_note("Note B", "Three words here", "College")
        metrics = AnalyticsManager.calculate_metrics(self.manager.notes)
        self.assertEqual(metrics["total_notes"], 2)
        self.assertEqual(metrics["category_counts"]["College"], 2)
        self.assertGreater(metrics["total_words"], 0)


if __name__ == "__main__":
    unittest.main()
