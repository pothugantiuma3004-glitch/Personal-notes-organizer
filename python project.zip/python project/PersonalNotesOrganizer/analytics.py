"""
analytics.py - Productivity Analytics and Notes Intelligence
Computes statistical insights, category distributions, tag frequencies, and formatted reports.
"""

from collections import Counter
from typing import List, Dict, Any
from reminder_manager import ReminderManager


class AnalyticsManager:
    """Calculates quantitative and qualitative metrics for personal notes."""

    @staticmethod
    def calculate_metrics(notes: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculates comprehensive metrics across all notes."""
        total_notes = len(notes)
        if total_notes == 0:
            return {
                "total_notes": 0,
                "total_words": 0,
                "avg_words": 0.0,
                "category_counts": {},
                "priority_counts": {},
                "status_counts": {},
                "completion_rate": 0.0,
                "top_tags": [],
                "reminders": {"overdue_count": 0, "due_today_count": 0, "upcoming_count": 0}
            }

        total_words = 0
        longest_note = None
        longest_words = 0

        categories = Counter()
        priorities = Counter()
        statuses = Counter()
        all_tags = []

        for note in notes:
            # Word count analysis
            content = note.get("content", "")
            title = note.get("title", "")
            words = len(f"{title} {content}".split())
            total_words += words
            if words > longest_words:
                longest_words = words
                longest_note = note.get("title", "")

            # Categories, priorities, statuses
            cat = note.get("category", "Uncategorized")
            categories[cat] += 1

            prio = note.get("priority", "Medium")
            priorities[prio] += 1

            stat = note.get("status", "Pending")
            statuses[stat] += 1

            # Tags
            for tag in note.get("tags", []):
                all_tags.append(tag)

        tag_counts = Counter(all_tags)
        reminders_summary = ReminderManager.get_reminders_summary(notes)

        completed_count = statuses.get("Completed", 0)
        completion_rate = (completed_count / total_notes) * 100 if total_notes > 0 else 0.0

        return {
            "total_notes": total_notes,
            "total_words": total_words,
            "avg_words": round(total_words / total_notes, 1),
            "longest_note": longest_note,
            "longest_words": longest_words,
            "category_counts": dict(categories),
            "priority_counts": dict(priorities),
            "status_counts": dict(statuses),
            "completion_rate": round(completion_rate, 1),
            "top_tags": tag_counts.most_common(10),
            "reminders": reminders_summary
        }

    @classmethod
    def generate_ascii_dashboard(cls, notes: List[Dict[str, Any]]) -> str:
        """Renders an ASCII productivity dashboard for terminal display."""
        metrics = cls.calculate_metrics(notes)
        total = metrics["total_notes"]

        if total == 0:
            return (
                "\n============================================================\n"
                "                  NOTES ANALYTICS DASHBOARD                 \n"
                "============================================================\n"
                "  No notes recorded yet! Create notes to view analytics.   \n"
                "============================================================\n"
            )

        lines = [
            "\n" + "=" * 62,
            "               PERSONAL PRODUCTIVITY ANALYTICS               ",
            "=" * 62,
            f" Total Notes: {total:<12} Total Words: {metrics['total_words']:<12} Avg Words/Note: {metrics['avg_words']}",
            f" Completion Rate: {metrics['completion_rate']}%   ({metrics['status_counts'].get('Completed', 0)} of {total} completed)",
            "-" * 62,
            " CATEGORY DISTRIBUTION:"
        ]

        for cat, count in sorted(metrics["category_counts"].items(), key=lambda x: x[1], reverse=True):
            pct = (count / total) * 100
            bar = "■" * int(pct / 5)
            lines.append(f"  • {cat:<15} {count:>3} notes ({pct:>5.1f}%) | {bar}")

        lines.extend([
            "-" * 62,
            " PRIORITY BREAKDOWN:"
        ])
        for prio in ["High", "Medium", "Low"]:
            count = metrics["priority_counts"].get(prio, 0)
            pct = (count / total) * 100
            lines.append(f"  • {prio:<10} {count:>3} notes ({pct:>5.1f}%)")

        lines.extend([
            "-" * 62,
            " STATUS SUMMARY:"
        ])
        for stat in ["Completed", "In Progress", "Pending"]:
            count = metrics["status_counts"].get(stat, 0)
            pct = (count / total) * 100
            lines.append(f"  • {stat:<12} {count:>3} notes ({pct:>5.1f}%)")

        rem = metrics["reminders"]
        lines.extend([
            "-" * 62,
            " DEADLINE STATUS:"
            f"  • Overdue:    {rem['overdue_count']:>3} notes" + (" (ACTION NEEDED!)" if rem['overdue_count'] > 0 else ""),
            f"  • Due Today:  {rem['due_today_count']:>3} notes" + (" (DUE TODAY!)" if rem['due_today_count'] > 0 else ""),
            f"  • Upcoming:   {rem['upcoming_count']:>3} notes (next 7 days)"
        ])

        if metrics["top_tags"]:
            lines.extend([
                "-" * 62,
                " TOP TAGS:"
            ])
            tag_line = "  " + ", ".join([f"#{tag} ({c})" for tag, c in metrics["top_tags"][:8]])
            lines.append(tag_line)

        lines.append("=" * 62 + "\n")
        return "\n".join(lines)
