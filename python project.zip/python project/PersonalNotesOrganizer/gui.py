"""
gui.py - Modern Tkinter Graphical User Interface
Full-featured desktop interface with real-time search, category filtering,
integrated note editor, deadline indicators, analytics popup, and export controls.
"""

import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime

from notes_manager import NotesManager
from search_manager import SearchManager
from reminder_manager import ReminderManager
from analytics import AnalyticsManager
from export_manager import ExportManager
from import_manager import ImportManager
from validation import VALID_CATEGORIES, VALID_PRIORITIES, VALID_STATUSES


class PersonalNotesApp:
    """Tkinter Desktop Application for Personal Notes Organizer."""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Personal Notes Organizer - Productivity Workspace")
        self.root.geometry("1150x740")
        self.root.minsize(980, 620)

        # Initialize Data Engine
        self.manager = NotesManager()
        self.active_note_id = None
        self.filtered_notes = []

        # Configure Style & Theme
        self.style = ttk.Style()
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass

        self.setup_styles()
        self.build_ui()
        self.refresh_notes_list()

    def setup_styles(self):
        """Configure ttk styles with a clean, modern color scheme."""
        bg_main = "#f4f6f9"
        accent_blue = "#1e3a8a"
        accent_teal = "#0f766e"

        self.root.configure(bg=bg_main)
        self.style.configure(".", background=bg_main, font=("Segoe UI", 10))
        self.style.configure("Header.TLabel", font=("Segoe UI", 14, "bold"), foreground="#1e293b", background=bg_main)
        self.style.configure("SubHeader.TLabel", font=("Segoe UI", 9), foreground="#64748b", background=bg_main)
        self.style.configure("Card.TFrame", background="#ffffff", relief="flat")
        
        self.style.configure("Primary.TButton", font=("Segoe UI", 9, "bold"), padding=6)
        self.style.configure("Success.TButton", font=("Segoe UI", 9, "bold"), padding=6)
        self.style.configure("Danger.TButton", font=("Segoe UI", 9, "bold"), padding=6)

        # Treeview styling
        self.style.configure("Treeview",
                             background="#ffffff",
                             foreground="#1e293b",
                             rowheight=26,
                             font=("Segoe UI", 9))
        self.style.configure("Treeview.Heading",
                             font=("Segoe UI", 9, "bold"),
                             foreground="#0f172a",
                             background="#e2e8f0")
        self.style.map("Treeview", background=[("selected", "#3b82f6")], foreground=[("selected", "#ffffff")])

    def build_ui(self):
        """Construct the main window layout."""
        # Top Header Bar
        header_frame = ttk.Frame(self.root, padding="14 10 14 10")
        header_frame.pack(fill=tk.X)

        title_box = ttk.Frame(header_frame)
        title_box.pack(side=tk.LEFT)
        lbl_title = ttk.Label(title_box, text="Personal Notes Organizer", style="Header.TLabel")
        lbl_title.pack(anchor="w")
        lbl_sub = ttk.Label(title_box, text="Organize thoughts, manage deadlines, and analyze productivity", style="SubHeader.TLabel")
        lbl_sub.pack(anchor="w")

        # Top Action Buttons
        btn_box = ttk.Frame(header_frame)
        btn_box.pack(side=tk.RIGHT)

        ttk.Button(btn_box, text="+ New Note", style="Primary.TButton", command=self.clear_editor_for_new).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_box, text="📊 Analytics", command=self.show_analytics_dialog).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_box, text="⏰ Reminders", command=self.show_reminders_dialog).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_box, text="📤 Export", command=self.show_export_dialog).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_box, text="📥 Import CSV", command=self.import_csv_dialog).pack(side=tk.LEFT, padx=3)

        # Search Bar Strip
        search_strip = ttk.Frame(self.root, padding="14 4 14 8")
        search_strip.pack(fill=tk.X)

        ttk.Label(search_strip, text="🔍 Search:", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=(0, 6))
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.apply_filters())
        search_entry = ttk.Entry(search_strip, textvariable=self.search_var, width=35)
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))

        ttk.Button(search_strip, text="Clear", width=8, command=lambda: self.search_var.set("")).pack(side=tk.LEFT, padx=(0, 10))

        # Quick Filter Dropdowns on Top
        ttk.Label(search_strip, text="Category:").pack(side=tk.LEFT, padx=(10, 4))
        self.cat_filter_var = tk.StringVar(value="All")
        self.cat_filter_combo = ttk.Combobox(search_strip, textvariable=self.cat_filter_var, state="readonly", width=12)
        self.cat_filter_combo.pack(side=tk.LEFT, padx=(0, 10))
        self.cat_filter_combo.bind("<<ComboboxSelected>>", lambda e: self.apply_filters())

        ttk.Label(search_strip, text="Priority:").pack(side=tk.LEFT, padx=(6, 4))
        self.prio_filter_var = tk.StringVar(value="All")
        prio_combo = ttk.Combobox(search_strip, textvariable=self.prio_filter_var, values=["All", "High", "Medium", "Low"], state="readonly", width=9)
        prio_combo.pack(side=tk.LEFT, padx=(0, 10))
        prio_combo.bind("<<ComboboxSelected>>", lambda e: self.apply_filters())

        ttk.Label(search_strip, text="Status:").pack(side=tk.LEFT, padx=(6, 4))
        self.status_filter_var = tk.StringVar(value="All")
        stat_combo = ttk.Combobox(search_strip, textvariable=self.status_filter_var, values=["All", "Pending", "In Progress", "Completed"], state="readonly", width=12)
        stat_combo.pack(side=tk.LEFT)
        stat_combo.bind("<<ComboboxSelected>>", lambda e: self.apply_filters())

        # Main Workspace Panes (Splitter between Notes List and Editor)
        main_paned = ttk.PanedWindow(self.root, orient=tk.VERTICAL)
        main_paned.pack(fill=tk.BOTH, expand=True, padx=14, pady=(0, 10))

        # UPPER PANE: Notes Table (Treeview)
        table_frame = ttk.Frame(main_paned)
        main_paned.add(table_frame, weight=3)

        columns = ("id", "title", "category", "priority", "status", "deadline", "tags", "updated_at")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")

        self.tree.heading("id", text="ID", command=lambda: self.sort_tree("id"))
        self.tree.heading("title", text="Title", command=lambda: self.sort_tree("title"))
        self.tree.heading("category", text="Category", command=lambda: self.sort_tree("category"))
        self.tree.heading("priority", text="Priority", command=lambda: self.sort_tree("priority"))
        self.tree.heading("status", text="Status", command=lambda: self.sort_tree("status"))
        self.tree.heading("deadline", text="Deadline", command=lambda: self.sort_tree("deadline"))
        self.tree.heading("tags", text="Tags", command=lambda: self.sort_tree("tags"))
        self.tree.heading("updated_at", text="Updated", command=lambda: self.sort_tree("updated_at"))

        self.tree.column("id", width=80, anchor="center")
        self.tree.column("title", width=260, anchor="w")
        self.tree.column("category", width=110, anchor="center")
        self.tree.column("priority", width=85, anchor="center")
        self.tree.column("status", width=105, anchor="center")
        self.tree.column("deadline", width=105, anchor="center")
        self.tree.column("tags", width=150, anchor="w")
        self.tree.column("updated_at", width=115, anchor="center")

        tree_scroll_y = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        tree_scroll_x = ttk.Scrollbar(table_frame, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=tree_scroll_y.set, xscrollcommand=tree_scroll_x.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        tree_scroll_y.grid(row=0, column=1, sticky="ns")
        tree_scroll_x.grid(row=1, column=0, sticky="ew")

        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)

        self.tree.bind("<<TreeviewSelect>>", self.on_note_selected)

        # LOWER PANE: Note Editor
        editor_frame = ttk.LabelFrame(main_paned, text=" Note Editor / Details ", padding=10)
        main_paned.add(editor_frame, weight=4)

        # Form row 1: Title & Category & Priority
        row1 = ttk.Frame(editor_frame)
        row1.pack(fill=tk.X, pady=(0, 6))

        ttk.Label(row1, text="Title:*", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT)
        self.title_entry = ttk.Entry(row1, font=("Segoe UI", 10))
        self.title_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(6, 12))

        ttk.Label(row1, text="Category:").pack(side=tk.LEFT)
        self.category_combo = ttk.Combobox(row1, values=VALID_CATEGORIES, width=14)
        self.category_combo.pack(side=tk.LEFT, padx=(6, 12))
        self.category_combo.set("Personal")

        ttk.Label(row1, text="Priority:").pack(side=tk.LEFT)
        self.priority_combo = ttk.Combobox(row1, values=VALID_PRIORITIES, state="readonly", width=10)
        self.priority_combo.pack(side=tk.LEFT, padx=(6, 0))
        self.priority_combo.set("Medium")

        # Form row 2: Status, Deadline, Tags
        row2 = ttk.Frame(editor_frame)
        row2.pack(fill=tk.X, pady=(0, 6))

        ttk.Label(row2, text="Status:").pack(side=tk.LEFT)
        self.status_combo = ttk.Combobox(row2, values=VALID_STATUSES, state="readonly", width=12)
        self.status_combo.pack(side=tk.LEFT, padx=(6, 12))
        self.status_combo.set("Pending")

        ttk.Label(row2, text="Deadline (YYYY-MM-DD):").pack(side=tk.LEFT)
        self.deadline_entry = ttk.Entry(row2, width=14)
        self.deadline_entry.pack(side=tk.LEFT, padx=(6, 12))

        ttk.Label(row2, text="Tags (comma separated):").pack(side=tk.LEFT)
        self.tags_entry = ttk.Entry(row2)
        self.tags_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(6, 0))

        # Content Editor Area
        content_frame = ttk.Frame(editor_frame)
        content_frame.pack(fill=tk.BOTH, expand=True, pady=(2, 8))

        ttk.Label(content_frame, text="Content:*", font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 2))
        self.content_text = tk.Text(content_frame, wrap=tk.WORD, font=("Consolas", 10), height=8, undo=True)
        content_scroll = ttk.Scrollbar(content_frame, orient=tk.VERTICAL, command=self.content_text.yview)
        self.content_text.configure(yscrollcommand=content_scroll.set)

        self.content_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        content_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        # Action Buttons below Editor
        actions_bar = ttk.Frame(editor_frame)
        actions_bar.pack(fill=tk.X)

        self.btn_save = ttk.Button(actions_bar, text="💾 Save Note", style="Success.TButton", command=self.save_current_note)
        self.btn_save.pack(side=tk.LEFT, padx=(0, 6))

        self.btn_clear = ttk.Button(actions_bar, text="Reset / New", command=self.clear_editor_for_new)
        self.btn_clear.pack(side=tk.LEFT, padx=6)

        self.btn_delete = ttk.Button(actions_bar, text="🗑️ Delete Note", style="Danger.TButton", command=self.delete_current_note)
        self.btn_delete.pack(side=tk.LEFT, padx=6)

        self.active_id_label = ttk.Label(actions_bar, text="Mode: Creating New Note", font=("Segoe UI", 9, "italic"), foreground="#475569")
        self.active_id_label.pack(side=tk.RIGHT, padx=6)

        # Status Bar at bottom of root window
        self.status_bar = ttk.Label(self.root, text="Ready", relief=tk.SUNKEN, anchor="w", padding="6 3 6 3")
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def refresh_notes_list(self):
        """Reload notes, update category filters, and re-populate the table."""
        self.manager.reload()
        cats = ["All"] + self.manager.get_categories()
        self.cat_filter_combo["values"] = cats
        if self.cat_filter_var.get() not in cats:
            self.cat_filter_var.set("All")

        self.apply_filters()

    def apply_filters(self):
        """Filters the notes based on search query and dropdown selections."""
        q = self.search_var.get().strip()
        cat = self.cat_filter_var.get()
        prio = self.prio_filter_var.get()
        stat = self.status_filter_var.get()

        self.filtered_notes = SearchManager.composite_search(
            notes=self.manager.notes,
            query=q,
            category=cat if cat != "All" else "",
            priority=prio if prio != "All" else "",
            status=stat if stat != "All" else ""
        )

        # Clear existing items in tree
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Repopulate
        for note in self.filtered_notes:
            tags_str = ", ".join(note.get("tags", []))
            deadline_str = note.get("deadline") or "-"
            updated_str = (note.get("updated_at") or "")[:10]

            self.tree.insert("", tk.END, iid=note["id"], values=(
                note["id"],
                note.get("title", ""),
                note.get("category", ""),
                note.get("priority", ""),
                note.get("status", ""),
                deadline_str,
                tags_str,
                updated_str
            ))

        reminders = ReminderManager.get_reminders_summary(self.manager.notes)
        urgent_text = f" | ⚠️ Overdue: {reminders['overdue_count']} | Due Today: {reminders['due_today_count']}" if reminders["has_urgent"] else ""
        self.set_status(f"Showing {len(self.filtered_notes)} of {len(self.manager.notes)} notes{urgent_text}")

    def on_note_selected(self, event):
        """Populates editor when a note row is selected in the Treeview."""
        selected = self.tree.selection()
        if not selected:
            return

        note_id = selected[0]
        note = self.manager.get_note_by_id(note_id)
        if not note:
            return

        self.active_note_id = note_id
        self.active_id_label.config(text=f"Editing: {note_id} (Created: {note.get('created_at', '')[:10]})")

        # Fill fields
        self.title_entry.delete(0, tk.END)
        self.title_entry.insert(0, note.get("title", ""))

        self.category_combo.set(note.get("category", "Personal"))
        self.priority_combo.set(note.get("priority", "Medium"))
        self.status_combo.set(note.get("status", "Pending"))

        self.deadline_entry.delete(0, tk.END)
        if note.get("deadline"):
            self.deadline_entry.insert(0, note["deadline"])

        self.tags_entry.delete(0, tk.END)
        self.tags_entry.insert(0, ", ".join(note.get("tags", [])))

        self.content_text.delete("1.0", tk.END)
        self.content_text.insert("1.0", note.get("content", ""))

    def clear_editor_for_new(self):
        """Clears editor fields to prepare for creating a fresh note."""
        self.active_note_id = None
        self.active_id_label.config(text="Mode: Creating New Note")
        self.tree.selection_remove(self.tree.selection())

        self.title_entry.delete(0, tk.END)
        self.category_combo.set("Personal")
        self.priority_combo.set("Medium")
        self.status_combo.set("Pending")
        self.deadline_entry.delete(0, tk.END)
        self.tags_entry.delete(0, tk.END)
        self.content_text.delete("1.0", tk.END)
        self.title_entry.focus_set()
        self.set_status("Editor cleared for new note.")

    def save_current_note(self):
        """Validates and saves the note currently in the editor (create or update)."""
        title = self.title_entry.get().strip()
        category = self.category_combo.get().strip()
        priority = self.priority_combo.get().strip()
        status = self.status_combo.get().strip()
        deadline = self.deadline_entry.get().strip() or None
        tags = self.tags_entry.get().strip()
        content = self.content_text.get("1.0", tk.END).strip()

        if not title:
            messagebox.showwarning("Validation Warning", "Please enter a note title.")
            self.title_entry.focus_set()
            return

        if not content:
            messagebox.showwarning("Validation Warning", "Please enter note content.")
            self.content_text.focus_set()
            return

        try:
            if self.active_note_id:
                # Update existing note
                self.manager.update_note(
                    note_id=self.active_note_id,
                    title=title,
                    content=content,
                    category=category,
                    tags=tags,
                    deadline=deadline,
                    priority=priority,
                    status=status
                )
                self.set_status(f"Note '{self.active_note_id}' updated successfully.")
            else:
                # Create new note
                new_note = self.manager.create_note(
                    title=title,
                    content=content,
                    category=category,
                    tags=tags,
                    deadline=deadline,
                    priority=priority,
                    status=status
                )
                self.active_note_id = new_note["id"]
                self.active_id_label.config(text=f"Editing: {new_note['id']}")
                self.set_status(f"New note created with ID: {new_note['id']}")

            self.refresh_notes_list()
            # Reselect in tree
            if self.active_note_id in self.tree.get_children():
                self.tree.selection_set(self.active_note_id)
                self.tree.see(self.active_note_id)

            messagebox.showinfo("Success", "Note saved successfully!")
        except Exception as e:
            messagebox.showerror("Save Error", str(e))

    def delete_current_note(self):
        """Deletes the currently active note after confirmation."""
        if not self.active_note_id:
            messagebox.showinfo("Information", "Please select a note to delete.")
            return

        note = self.manager.get_note_by_id(self.active_note_id)
        title = note.get("title", "") if note else self.active_note_id

        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to permanently delete:\n'{title}' ({self.active_note_id})?"):
            self.manager.delete_note(self.active_note_id)
            self.clear_editor_for_new()
            self.refresh_notes_list()
            messagebox.showinfo("Deleted", "Note has been deleted.")

    def sort_tree(self, col):
        """Sort treeview items by column."""
        # Simple sorting toggle
        items = [(self.tree.set(k, col), k) for k in self.tree.get_children("")]
        items.sort(reverse=getattr(self, f"_sort_rev_{col}", False))
        setattr(self, f"_sort_rev_{col}", not getattr(self, f"_sort_rev_{col}", False))

        for index, (val, k) in enumerate(items):
            self.tree.move(k, "", index)

    def show_analytics_dialog(self):
        """Opens a modal popup with productivity analytics and insights."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Productivity Analytics Dashboard")
        dlg.geometry("640x540")
        dlg.transient(self.root)

        metrics = AnalyticsManager.calculate_metrics(self.manager.notes)

        lbl = ttk.Label(dlg, text="Productivity Insights & Statistics", font=("Segoe UI", 12, "bold"))
        lbl.pack(pady=12)

        txt = tk.Text(dlg, wrap=tk.WORD, font=("Consolas", 10), padx=10, pady=10)
        txt.pack(fill=tk.BOTH, expand=True, padx=14, pady=(0, 10))

        dashboard_report = AnalyticsManager.generate_ascii_dashboard(self.manager.notes)
        txt.insert("1.0", dashboard_report)
        txt.config(state=tk.DISABLED)

        ttk.Button(dlg, text="Close", command=dlg.destroy).pack(pady=(0, 10))

    def show_reminders_dialog(self):
        """Opens a dialog listing all overdue, due today, and upcoming notes."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Deadlines & Reminder Alerts")
        dlg.geometry("700x480")
        dlg.transient(self.root)

        summary = ReminderManager.get_reminders_summary(self.manager.notes)

        ttk.Label(dlg, text="Deadline Tracker & Upcoming Deadlines", font=("Segoe UI", 12, "bold")).pack(pady=10)

        tree = ttk.Treeview(dlg, columns=("id", "title", "deadline", "status", "urgency"), show="headings")
        tree.heading("id", text="ID")
        tree.heading("title", text="Title")
        tree.heading("deadline", text="Deadline")
        tree.heading("status", text="Status")
        tree.heading("urgency", text="Urgency")

        tree.column("id", width=80, anchor="center")
        tree.column("title", width=260)
        tree.column("deadline", width=100, anchor="center")
        tree.column("status", width=90, anchor="center")
        tree.column("urgency", width=140, anchor="center")

        tree.pack(fill=tk.BOTH, expand=True, padx=14, pady=10)

        all_urgent = summary["overdue_notes"] + summary["due_today_notes"] + summary["upcoming_notes"]
        for n in all_urgent:
            tree.insert("", tk.END, values=(
                n["id"],
                n["title"],
                n.get("deadline", "---"),
                n.get("status", "Pending"),
                n["reminder_info"]["label"]
            ))

        if not all_urgent:
            ttk.Label(dlg, text="All caught up! No urgent or upcoming deadlines.", font=("Segoe UI", 10, "italic"), foreground="green").pack(pady=10)

        ttk.Button(dlg, text="Close", command=dlg.destroy).pack(pady=10)

    def show_export_dialog(self):
        """Dialog to export notes to CSV, TXT, or Markdown."""
        if not self.manager.notes:
            messagebox.showinfo("Export", "No notes available to export.")
            return

        choice_dlg = tk.Toplevel(self.root)
        choice_dlg.title("Export Notes")
        choice_dlg.geometry("400x260")
        choice_dlg.resizable(False, False)
        choice_dlg.transient(self.root)

        ttk.Label(choice_dlg, text="Select Export Format", font=("Segoe UI", 11, "bold")).pack(pady=14)

        def do_export(fmt):
            try:
                if fmt == "csv":
                    path = ExportManager.export_to_csv(self.manager.notes)
                elif fmt == "txt":
                    path = ExportManager.export_to_txt(self.manager.notes)
                elif fmt == "md":
                    path = ExportManager.export_to_markdown(self.manager.notes)
                else:
                    return

                choice_dlg.destroy()
                messagebox.showinfo("Export Success", f"Notes exported successfully to:\n\n{path}")
            except Exception as e:
                messagebox.showerror("Export Failed", str(e))

        ttk.Button(choice_dlg, text="📄 Export to CSV (Spreadsheets)", width=32, command=lambda: do_export("csv")).pack(pady=6)
        ttk.Button(choice_dlg, text="📝 Export to TXT (Readable Report)", width=32, command=lambda: do_export("txt")).pack(pady=6)
        ttk.Button(choice_dlg, text="📑 Export to Markdown (Obsidian/GitHub)", width=32, command=lambda: do_export("md")).pack(pady=6)
        ttk.Button(choice_dlg, text="Cancel", width=15, command=choice_dlg.destroy).pack(pady=12)

    def import_csv_dialog(self):
        """Allows user to select and import a CSV file with notes."""
        file_selected = filedialog.askopenfilename(
            title="Select CSV file to import",
            filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        if not file_selected:
            return

        res = ImportManager.import_from_csv(file_selected, self.manager, skip_duplicate_titles=True)
        if res["success"]:
            self.refresh_notes_list()
            msg = f"Import Completed!\n\nImported: {res['imported']}\nSkipped: {res['skipped']}\nTotal: {res['total_rows']}"
            if res["errors"]:
                msg += f"\n\nNotices:\n" + "\n".join(res["errors"][:5])
            messagebox.showinfo("CSV Import", msg)
        else:
            messagebox.showerror("CSV Import Failed", "\n".join(res["errors"]))

    def set_status(self, text: str):
        """Update status bar label."""
        self.status_bar.config(text=text)


def launch_gui_app():
    """Entry point for the GUI application."""
    root = tk.Tk()
    app = PersonalNotesApp(root)
    root.mainloop()


if __name__ == "__main__":
    launch_gui_app()
