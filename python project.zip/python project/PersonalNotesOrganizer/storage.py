"""
storage.py - Reliable Local JSON Storage & Backup System
Handles atomic file writes, automatic backups, error recovery, and directory management.
"""

import os
import json
import shutil
import tempfile
from datetime import datetime
from typing import List, Dict, Any, Optional

DEFAULT_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
DEFAULT_NOTES_FILE = os.path.join(DEFAULT_DATA_DIR, "notes.json")
DEFAULT_BACKUP_FILE = os.path.join(DEFAULT_DATA_DIR, "backup.json")


def ensure_directory(path: str) -> None:
    """Ensure directory exists for the given file or directory path."""
    dirname = os.path.dirname(path) if os.path.splitext(path)[1] else path
    if dirname and not os.path.exists(dirname):
        os.makedirs(dirname, exist_ok=True)


def create_backup(source_path: str = DEFAULT_NOTES_FILE,
                  backup_path: str = DEFAULT_BACKUP_FILE) -> bool:
    """Copies current notes file to backup path."""
    try:
        if os.path.exists(source_path) and os.path.getsize(source_path) > 0:
            ensure_directory(backup_path)
            shutil.copy2(source_path, backup_path)
            return True
    except Exception as e:
        print(f"[Storage Warning] Backup failed: {e}")
    return False


def load_notes(filepath: str = DEFAULT_NOTES_FILE,
               backup_path: str = DEFAULT_BACKUP_FILE) -> List[Dict[str, Any]]:
    """
    Safely loads notes from JSON file.
    If the file is missing, creates it with [].
    If corrupted, attempts automatic recovery from backup.
    """
    ensure_directory(filepath)

    if not os.path.exists(filepath):
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump([], f, indent=2)
            return []
        except Exception as e:
            print(f"[Storage Error] Could not initialize {filepath}: {e}")
            return []

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
            else:
                raise ValueError("Notes JSON root element must be a list.")
    except (json.JSONDecodeError, ValueError) as err:
        print(f"[Storage Warning] Primary notes file corrupted ({err}). Attempting backup restore...")
        # Try restoring from backup
        if os.path.exists(backup_path):
            try:
                with open(backup_path, "r", encoding="utf-8") as bf:
                    backup_data = json.load(bf)
                    if isinstance(backup_data, list):
                        # Preserve corrupted file
                        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                        corrupt_copy = f"{filepath}.corrupt_{ts}.bak"
                        shutil.copy2(filepath, corrupt_copy)
                        # Restore backup
                        shutil.copy2(backup_path, filepath)
                        print(f"[Storage] Successfully restored notes from backup! (Corrupt file saved to {corrupt_copy})")
                        return backup_data
            except Exception as b_err:
                print(f"[Storage Error] Backup restore also failed: {b_err}")

        # If backup not available, archive corrupted file and start clean
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        corrupt_copy = f"{filepath}.corrupt_{ts}.bak"
        try:
            shutil.copy2(filepath, corrupt_copy)
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump([], f, indent=2)
            print(f"[Storage] Initialized clean database. Corrupted copy saved to {corrupt_copy}.")
        except Exception:
            pass
        return []


def save_notes(notes: List[Dict[str, Any]],
               filepath: str = DEFAULT_NOTES_FILE,
               backup_path: str = DEFAULT_BACKUP_FILE,
               make_backup: bool = True) -> bool:
    """
    Saves notes using atomic write (write to temp file then replace).
    Automatically backs up the existing database prior to writing.
    """
    ensure_directory(filepath)

    # Backup existing file before overwriting
    if make_backup and os.path.exists(filepath) and os.path.getsize(filepath) > 0:
        create_backup(filepath, backup_path)

    # Atomic write pattern to prevent incomplete writes on sudden exit
    dir_name = os.path.dirname(os.path.abspath(filepath))
    temp_file = None
    try:
        fd, temp_path = tempfile.mkstemp(dir=dir_name, prefix="notes_", suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(notes, f, indent=2, ensure_ascii=False)
        
        # Atomically replace destination with temp file
        os.replace(temp_path, filepath)
        return True
    except Exception as e:
        print(f"[Storage Error] Failed to save notes: {e}")
        if temp_file and os.path.exists(temp_file):
            try:
                os.remove(temp_file)
            except OSError:
                pass
        return False


def restore_from_backup(backup_path: str = DEFAULT_BACKUP_FILE,
                        filepath: str = DEFAULT_NOTES_FILE) -> List[Dict[str, Any]]:
    """Restores primary database from backup file."""
    if not os.path.exists(backup_path):
        raise FileNotFoundError(f"Backup file not found at: {backup_path}")
    with open(backup_path, "r", encoding="utf-8") as f:
        data = json.load(f)
        if not isinstance(data, list):
            raise ValueError("Backup content is not a valid notes list.")
    save_notes(data, filepath=filepath, make_backup=False)
    return data
