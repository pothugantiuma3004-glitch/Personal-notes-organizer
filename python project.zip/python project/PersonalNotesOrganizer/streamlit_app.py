"""
streamlit_app.py - Modern Web UI for Personal Notes Organizer
Built with Streamlit for a reactive, polished user experience.
Integrates directly with the existing storage, search, reminders, analytics, export, and import engines.
"""

import os
import sys
import tempfile
from datetime import datetime, date

import streamlit as st
import pandas as pd

# Add current folder to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from notes_manager import NotesManager
from search_manager import SearchManager
from reminder_manager import ReminderManager
from analytics import AnalyticsManager
from export_manager import ExportManager
from import_manager import ImportManager
from validation import VALID_CATEGORIES, VALID_PRIORITIES, VALID_STATUSES


# Initialize Streamlit Page Config
st.set_page_config(
    page_title="Personal Notes Organizer",
    page_icon="📓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for modern styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1e3a8a;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.05rem;
        color: #64748b;
        margin-bottom: 1.5rem;
    }
    .note-card {
        background-color: #ffffff;
        border-radius: 10px;
        padding: 1.2rem;
        margin-bottom: 1rem;
        border-left: 5px solid #3b82f6;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }
    .badge {
        display: inline-block;
        padding: 0.2rem 0.6rem;
        font-size: 0.78rem;
        font-weight: 600;
        border-radius: 9999px;
        margin-right: 0.4rem;
    }
    .badge-high { background-color: #fee2e2; color: #991b1b; }
    .badge-med { background-color: #fef3c7; color: #92400e; }
    .badge-low { background-color: #e0e7ff; color: #3730a3; }
    .badge-done { background-color: #dcfce7; color: #166534; }
    .badge-progress { background-color: #e0f2fe; color: #075985; }
    .badge-pending { background-color: #f1f5f9; color: #475569; }
    .tag-pill {
        display: inline-block;
        background-color: #f1f5f9;
        color: #334155;
        border-radius: 6px;
        padding: 0.15rem 0.5rem;
        font-size: 0.75rem;
        margin: 0.15rem;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def get_manager():
    """Returns singleton instance of NotesManager."""
    return NotesManager()


def main():
    manager = get_manager()
    manager.reload()

    # Sidebar Navigation & Summary
    with st.sidebar:
        st.markdown("### 📓 Notes Workspace")
        st.caption("Local-first personal intelligence & productivity")

        reminders = ReminderManager.get_reminders_summary(manager.notes)
        if reminders["overdue_count"] > 0:
            st.error(f"⚠️ **{reminders['overdue_count']} Overdue Note(s)**")
        elif reminders["due_today_count"] > 0:
            st.warning(f"⏰ **{reminders['due_today_count']} Note(s) Due Today**")

        st.divider()

        nav_choice = st.radio(
            "Navigation",
            [
                "📋 All Notes & Search",
                "📝 Create Note",
                "📊 Analytics & Insights",
                "⏰ Deadlines & Reminders",
                "💾 Export & Import"
            ],
            index=0
        )

        st.divider()
        st.metric(label="Total Notes", value=len(manager.notes))
        completed = sum(1 for n in manager.notes if n.get("status") == "Completed")
        st.caption(f"Completed: {completed} / {len(manager.notes)}")

    # Header
    st.markdown('<div class="main-header">Personal Notes Organizer</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Create, search, organize, and analyze personal notes with guaranteed local storage</div>', unsafe_allow_html=True)

    # PAGE 1: ALL NOTES & SEARCH
    if nav_choice == "📋 All Notes & Search":
        col1, col2, col3, col4 = st.columns([3, 2, 2, 2])
        with col1:
            query = st.text_input("🔍 Search keyword", placeholder="Search title, content, or tags...")
        with col2:
            all_cats = ["All"] + manager.get_categories()
            category = st.selectbox("Category", all_cats)
        with col3:
            priority = st.selectbox("Priority", ["All", "High", "Medium", "Low"])
        with col4:
            status = st.selectbox("Status", ["All", "Pending", "In Progress", "Completed"])

        results = SearchManager.composite_search(
            notes=manager.notes,
            query=query,
            category=category if category != "All" else "",
            priority=priority if priority != "All" else "",
            status=status if status != "All" else ""
        )

        view_mode = st.radio("View Mode", ["Cards View", "Table View"], horizontal=True)

        if not results:
            st.info("No notes found matching the selected criteria. Try adjusting your search filters or create a new note!")
        elif view_mode == "Table View":
            df_data = []
            for n in results:
                df_data.append({
                    "ID": n.get("id"),
                    "Title": n.get("title"),
                    "Category": n.get("category"),
                    "Priority": n.get("priority"),
                    "Status": n.get("status"),
                    "Deadline": n.get("deadline") or "-",
                    "Tags": ", ".join(n.get("tags", [])),
                    "Updated": (n.get("updated_at") or "")[:10]
                })
            df = pd.DataFrame(df_data)
            st.dataframe(df, use_container_width=True, hide_index=True)
        else:
            for note in results:
                prio = note.get("priority", "Medium")
                prio_badge = f"badge-{prio.lower()}"
                stat = note.get("status", "Pending")
                stat_badge = "badge-done" if stat == "Completed" else ("badge-progress" if stat == "In Progress" else "badge-pending")

                rem = ReminderManager.evaluate_note(note)
                deadline_text = f"📅 Due: {note.get('deadline')}" if note.get("deadline") else "📅 No deadline"
                if rem["status"] == "Overdue":
                    deadline_text += f" ⚠️ ({rem['label']})"

                with st.expander(f"**[{note['id']}] {note['title']}** — *{note.get('category')}*"):
                    mcol1, mcol2 = st.columns([4, 1])
                    with mcol1:
                        st.markdown(
                            f'<span class="badge {prio_badge}">{prio} Priority</span>'
                            f'<span class="badge {stat_badge}">{stat}</span>'
                            f'<span>{deadline_text}</span>',
                            unsafe_allow_html=True
                        )
                        st.markdown(f"**Updated:** `{note.get('updated_at', '')[:10]}` | **Created:** `{note.get('created_at', '')[:10]}`")
                    with mcol2:
                        pass

                    st.markdown("---")
                    st.markdown(note.get("content", ""))

                    if note.get("tags"):
                        st.markdown(" ".join([f'<span class="tag-pill">#{t}</span>' for t in note["tags"]]), unsafe_allow_html=True)

                    st.markdown("---")
                    # Actions Row
                    bcol1, bcol2, bcol3 = st.columns([2, 2, 4])
                    with bcol1:
                        if stat != "Completed":
                            if st.button("Mark Completed", key=f"done_{note['id']}"):
                                manager.update_note(note['id'], status="Completed")
                                st.rerun()
                        else:
                            if st.button("Reopen Note", key=f"reopen_{note['id']}"):
                                manager.update_note(note['id'], status="In Progress")
                                st.rerun()
                    with bcol2:
                        if st.button("🗑️ Delete", key=f"del_{note['id']}", type="secondary"):
                            manager.delete_note(note['id'])
                            st.success(f"Deleted {note['id']}")
                            st.rerun()

    # PAGE 2: CREATE NOTE
    elif nav_choice == "📝 Create Note":
        st.markdown("### 📝 Create a New Note")
        with st.form("create_note_form", clear_on_submit=True):
            col1, col2 = st.columns([3, 1])
            with col1:
                title = st.text_input("Title *", placeholder="e.g., Computer Networks Midterm Preparation")
            with col2:
                category = st.selectbox("Category", VALID_CATEGORIES)

            col3, col4, col5 = st.columns(3)
            with col3:
                priority = st.selectbox("Priority", VALID_PRIORITIES, index=1)
            with col4:
                status = st.selectbox("Status", VALID_STATUSES, index=0)
            with col5:
                deadline = st.date_input("Deadline (optional)", value=None)

            tags = st.text_input("Tags (comma separated)", placeholder="e.g. exam, networks, study")
            content = st.text_area("Content / Markdown Notes *", height=200, placeholder="Write your notes here...")

            submitted = st.form_submit_button("💾 Save Note", type="primary")

            if submitted:
                if not title.strip():
                    st.error("Title cannot be empty.")
                elif not content.strip():
                    st.error("Content cannot be empty.")
                else:
                    dl_str = deadline.strftime("%Y-%m-%d") if deadline else None
                    try:
                        new_note = manager.create_note(
                            title=title,
                            content=content,
                            category=category,
                            tags=tags,
                            deadline=dl_str,
                            priority=priority,
                            status=status
                        )
                        st.success(f"Note '{new_note['title']}' created successfully with ID `{new_note['id']}`!")
                    except Exception as e:
                        st.error(f"Failed to create note: {e}")

    # PAGE 3: ANALYTICS
    elif nav_choice == "📊 Analytics & Insights":
        st.markdown("### 📊 Productivity & Notes Intelligence")
        metrics = AnalyticsManager.calculate_metrics(manager.notes)

        # High-level KPIs
        k1, k2, k3, k4 = st.columns(4)
        k1.metric("Total Notes", metrics["total_notes"])
        k2.metric("Total Words Written", f"{metrics['total_words']:,}")
        k3.metric("Avg Words / Note", metrics["avg_words"])
        k4.metric("Completion Rate", f"{metrics['completion_rate']}%")

        st.divider()

        # Visual Charts
        ch1, ch2 = st.columns(2)
        with ch1:
            st.markdown("#### Notes by Category")
            if metrics["category_counts"]:
                cat_df = pd.DataFrame(list(metrics["category_counts"].items()), columns=["Category", "Notes Count"])
                st.bar_chart(cat_df.set_index("Category"))
            else:
                st.info("No category data available.")

        with ch2:
            st.markdown("#### Notes by Priority")
            if metrics["priority_counts"]:
                prio_df = pd.DataFrame(list(metrics["priority_counts"].items()), columns=["Priority", "Notes Count"])
                st.bar_chart(prio_df.set_index("Priority"))
            else:
                st.info("No priority data available.")

        st.divider()

        ch3, ch4 = st.columns(2)
        with ch3:
            st.markdown("#### Notes Status")
            if metrics["status_counts"]:
                stat_df = pd.DataFrame(list(metrics["status_counts"].items()), columns=["Status", "Notes Count"])
                st.bar_chart(stat_df.set_index("Status"))
        with ch4:
            st.markdown("#### Top Tags Frequency")
            if metrics["top_tags"]:
                tags_df = pd.DataFrame(metrics["top_tags"], columns=["Tag", "Frequency"])
                st.bar_chart(tags_df.set_index("Tag"))
            else:
                st.info("No tags recorded yet.")

        # Text Dashboard report expander
        with st.expander("📄 View Plaintext ASCII Terminal Dashboard"):
            st.code(AnalyticsManager.generate_ascii_dashboard(manager.notes), language="text")

    # PAGE 4: DEADLINES & REMINDERS
    elif nav_choice == "⏰ Deadlines & Reminders":
        st.markdown("### ⏰ Deadlines & Reminder Alerts")
        summary = ReminderManager.get_reminders_summary(manager.notes)

        c1, c2, c3 = st.columns(3)
        c1.metric("Overdue Notes", summary["overdue_count"], delta=f"-{summary['overdue_count']}" if summary['overdue_count'] else None)
        c2.metric("Due Today", summary["due_today_count"])
        c3.metric("Upcoming (7 Days)", summary["upcoming_count"])

        st.divider()

        if summary["overdue_notes"]:
            st.error("#### 🚨 Overdue Notes (Immediate Action Required)")
            for n in summary["overdue_notes"]:
                st.markdown(f"- **[{n['id']}] {n['title']}** — Due `{n['deadline']}` (`{n['reminder_info']['label']}`) | Category: *{n['category']}*")

        if summary["due_today_notes"]:
            st.warning("#### ⚠️ Notes Due Today")
            for n in summary["due_today_notes"]:
                st.markdown(f"- **[{n['id']}] {n['title']}** — Due Today! | Category: *{n['category']}*")

        if summary["upcoming_notes"]:
            st.info("#### 📅 Upcoming in Next 7 Days")
            for n in summary["upcoming_notes"]:
                st.markdown(f"- **[{n['id']}] {n['title']}** — Due `{n['deadline']}` (`{n['reminder_info']['label']}`) | Priority: *{n['priority']}*")

        if not summary["overdue_notes"] and not summary["due_today_notes"] and not summary["upcoming_notes"]:
            st.success("🎉 You are completely caught up! No upcoming or overdue deadlines.")

    # PAGE 5: EXPORTS & IMPORTS
    elif nav_choice == "💾 Export & Import":
        st.markdown("### 💾 Export & Import Data")

        exp_col, imp_col = st.columns(2)

        with exp_col:
            st.markdown("#### 📤 Export Notes Archive")
            st.caption("Download your entire notes database in your preferred format.")

            # CSV Download
            csv_path = ExportManager.export_to_csv(manager.notes)
            with open(csv_path, "r", encoding="utf-8") as f:
                csv_bytes = f.read()
            st.download_button(
                label="📄 Download as CSV (Spreadsheets)",
                data=csv_bytes,
                file_name="personal_notes_export.csv",
                mime="text/csv",
                use_container_width=True
            )

            # TXT Download
            txt_path = ExportManager.export_to_txt(manager.notes)
            with open(txt_path, "r", encoding="utf-8") as f:
                txt_bytes = f.read()
            st.download_button(
                label="📝 Download as Formatted TXT Report",
                data=txt_bytes,
                file_name="personal_notes_report.txt",
                mime="text/plain",
                use_container_width=True
            )

            # Markdown Download
            md_path = ExportManager.export_to_markdown(manager.notes)
            with open(md_path, "r", encoding="utf-8") as f:
                md_bytes = f.read()
            st.download_button(
                label="📑 Download as Markdown (Obsidian / GitHub)",
                data=md_bytes,
                file_name="personal_notes_export.md",
                mime="text/markdown",
                use_container_width=True
            )

        with imp_col:
            st.markdown("#### 📥 Bulk CSV Import")
            st.caption("Upload a `.csv` file containing `title` and `content` columns.")

            uploaded_file = st.file_uploader("Choose a CSV file", type=["csv"])
            if uploaded_file is not None:
                # Save to a temporary file
                with tempfile.NamedTemporaryFile(delete=False, suffix=".csv") as tmp:
                    tmp.write(uploaded_file.getvalue())
                    tmp_path = tmp.name

                res = ImportManager.import_from_csv(tmp_path, manager, skip_duplicate_titles=True)
                os.remove(tmp_path)

                if res["success"]:
                    st.success(f"Successfully imported {res['imported']} note(s)! (Skipped {res['skipped']} duplicates/invalid)")
                    if res["errors"]:
                        with st.expander("Import Notices / Warnings"):
                            for err in res["errors"]:
                                st.write(f"- {err}")
                    st.button("🔄 Refresh Data", on_click=lambda: manager.reload())
                else:
                    st.error(f"Import failed: {', '.join(res['errors'])}")


if __name__ == "__main__":
    main()
