"""
validation.py - Input validation and sanitation module
Ensures data integrity across user inputs, CLI prompts, GUI fields, and CSV imports.
"""

from datetime import datetime
from typing import List, Tuple, Union, Optional

VALID_CATEGORIES = ["College", "Personal", "Projects", "Ideas"]
VALID_PRIORITIES = ["Low", "Medium", "High"]
VALID_STATUSES = ["Pending", "In Progress", "Completed"]


def validate_title(title: str) -> Tuple[bool, str]:
    """Validate note title."""
    if not isinstance(title, str):
        return False, "Title must be a text string."
    cleaned = title.strip()
    if not cleaned:
        return False, "Title cannot be empty or contain only whitespace."
    if len(cleaned) > 200:
        return False, "Title cannot exceed 200 characters."
    return True, ""


def validate_content(content: str) -> Tuple[bool, str]:
    """Validate note content."""
    if not isinstance(content, str):
        return False, "Content must be a text string."
    cleaned = content.strip()
    if not cleaned:
        return False, "Content cannot be empty."
    return True, ""


def validate_category(category: str) -> Tuple[bool, str]:
    """Validate note category (custom categories allowed if non-empty)."""
    if not isinstance(category, str):
        return False, "Category must be a text string."
    cleaned = category.strip()
    if not cleaned:
        return False, "Category cannot be empty."
    return True, ""


def validate_priority(priority: str) -> Tuple[bool, str]:
    """Validate note priority: Low, Medium, High."""
    if not isinstance(priority, str):
        return False, "Priority must be a string."
    cleaned = priority.strip().capitalize()
    if cleaned not in VALID_PRIORITIES:
        return False, f"Priority must be one of {VALID_PRIORITIES}."
    return True, ""


def validate_status(status: str) -> Tuple[bool, str]:
    """Validate note status: Pending, In Progress, Completed."""
    if not isinstance(status, str):
        return False, "Status must be a string."
    cleaned = status.strip().title()
    if cleaned not in VALID_STATUSES:
        return False, f"Status must be one of {VALID_STATUSES}."
    return True, ""


def validate_date(date_str: Optional[str]) -> Tuple[bool, str]:
    """
    Validate date format (YYYY-MM-DD).
    Empty string or None is valid (representing no deadline).
    """
    if date_str is None:
        return True, ""
    cleaned = str(date_str).strip()
    if not cleaned:
        return True, ""
    try:
        datetime.strptime(cleaned, "%Y-%m-%d")
        return True, ""
    except ValueError:
        return False, f"Invalid date '{cleaned}'. Expected format: YYYY-MM-DD."


def sanitize_tags(tags_input: Union[str, List[str], None]) -> List[str]:
    """
    Sanitizes tags from comma-separated string or list.
    Removes leading '#', trims whitespace, lowercases, and deduplicates.
    """
    if tags_input is None:
        return []

    if isinstance(tags_input, str):
        raw_tags = tags_input.replace(";", ",").split(",")
    elif isinstance(tags_input, (list, tuple, set)):
        raw_tags = [str(t) for t in tags_input]
    else:
        raw_tags = [str(tags_input)]

    cleaned_tags = []
    seen = set()

    for tag in raw_tags:
        cleaned = tag.strip().lstrip("#").lower()
        # Remove internal special characters except dashes and underscores
        cleaned = "".join(c for c in cleaned if c.isalnum() or c in ("-", "_"))
        if cleaned and cleaned not in seen:
            seen.add(cleaned)
            cleaned_tags.append(cleaned)

    return sorted(cleaned_tags)


def validate_note_payload(data: dict) -> Tuple[bool, List[str]]:
    """
    Validates a complete note payload dictionary.
    Returns (is_valid, list_of_error_messages).
    """
    errors = []

    if not isinstance(data, dict):
        return False, ["Payload must be a dictionary."]

    ok, msg = validate_title(data.get("title", ""))
    if not ok:
        errors.append(msg)

    ok, msg = validate_content(data.get("content", ""))
    if not ok:
        errors.append(msg)

    if "category" in data:
        ok, msg = validate_category(data.get("category", ""))
        if not ok:
            errors.append(msg)

    if "priority" in data and data["priority"]:
        ok, msg = validate_priority(data["priority"])
        if not ok:
            errors.append(msg)

    if "status" in data and data["status"]:
        ok, msg = validate_status(data["status"])
        if not ok:
            errors.append(msg)

    if "deadline" in data and data["deadline"]:
        ok, msg = validate_date(data["deadline"])
        if not ok:
            errors.append(msg)

    return len(errors) == 0, errors
