"""
search_manager.py - Fast Search and Multi-Criteria Filtering Engine
Enables searching by keywords, tags, categories, priorities, statuses, and date ranges.
"""

from datetime import datetime
from typing import List, Dict, Any, Optional


class SearchManager:
    """Provides advanced query, filtering, and tag search algorithms."""

    @staticmethod
    def search_by_keyword(notes: List[Dict[str, Any]], keyword: str) -> List[Dict[str, Any]]:
        """
        Performs case-insensitive keyword search across note title, content, and tags.
        """
        if not keyword or not keyword.strip():
            return notes

        kw = keyword.strip().lower()
        results = []
        for note in notes:
            title = note.get("title", "").lower()
            content = note.get("content", "").lower()
            tags = [t.lower() for t in note.get("tags", [])]

            if kw in title or kw in content or any(kw in t for t in tags):
                results.append(note)

        return results

    @staticmethod
    def filter_by_category(notes: List[Dict[str, Any]], category: str) -> List[Dict[str, Any]]:
        """Filters notes by category (case-insensitive)."""
        if not category or category.strip().lower() in ("all", ""):
            return notes

        cat = category.strip().lower()
        return [n for n in notes if n.get("category", "").lower() == cat]

    @staticmethod
    def filter_by_tag(notes: List[Dict[str, Any]], tag: str) -> List[Dict[str, Any]]:
        """Filters notes that contain a specific tag."""
        if not tag or not tag.strip():
            return notes

        target = tag.strip().lstrip("#").lower()
        return [
            n for n in notes
            if any(t.lower() == target for t in n.get("tags", []))
        ]

    @staticmethod
    def filter_by_priority(notes: List[Dict[str, Any]], priority: str) -> List[Dict[str, Any]]:
        """Filters notes by priority (Low, Medium, High)."""
        if not priority or priority.strip().lower() in ("all", ""):
            return notes
        prio = priority.strip().capitalize()
        return [n for n in notes if n.get("priority", "").capitalize() == prio]

    @staticmethod
    def filter_by_status(notes: List[Dict[str, Any]], status: str) -> List[Dict[str, Any]]:
        """Filters notes by status (Pending, In Progress, Completed)."""
        if not status or status.strip().lower() in ("all", ""):
            return notes
        stat = status.strip().title()
        return [n for n in notes if n.get("status", "").title() == stat]

    @staticmethod
    def filter_by_date_range(notes: List[Dict[str, Any]],
                             start_date: Optional[str] = None,
                             end_date: Optional[str] = None,
                             date_field: str = "created_at") -> List[Dict[str, Any]]:
        """
        Filters notes within a date range (YYYY-MM-DD) on created_at or deadline.
        """
        results = []
        start_dt = datetime.strptime(start_date.strip(), "%Y-%m-%d") if start_date and start_date.strip() else None
        end_dt = datetime.strptime(end_date.strip(), "%Y-%m-%d") if end_date and end_date.strip() else None

        for note in notes:
            raw_date = note.get(date_field)
            if not raw_date:
                continue

            try:
                # Support full ISO timestamp or simple YYYY-MM-DD
                clean_str = str(raw_date)[:10]
                note_dt = datetime.strptime(clean_str, "%Y-%m-%d")

                if start_dt and note_dt < start_dt:
                    continue
                if end_dt and note_dt > end_dt:
                    continue

                results.append(note)
            except ValueError:
                continue

        return results

    @classmethod
    def composite_search(cls,
                         notes: List[Dict[str, Any]],
                         query: str = "",
                         category: str = "",
                         tag: str = "",
                         priority: str = "",
                         status: str = "",
                         start_date: Optional[str] = None,
                         end_date: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Combines all filters into a single unified search query.
        """
        filtered = notes
        if query:
            filtered = cls.search_by_keyword(filtered, query)
        if category and category.lower() != "all":
            filtered = cls.filter_by_category(filtered, category)
        if tag:
            filtered = cls.filter_by_tag(filtered, tag)
        if priority and priority.lower() != "all":
            filtered = cls.filter_by_priority(filtered, priority)
        if status and status.lower() != "all":
            filtered = cls.filter_by_status(filtered, status)
        if start_date or end_date:
            filtered = cls.filter_by_date_range(filtered, start_date, end_date)
        return filtered
