"""
main.py - Personal Notes Organizer
Primary CLI Terminal Application & Launcher
Provides an interactive command-line interface and direct launch for Tkinter GUI.
"""

import sys
import os
from datetime import datetime

from notes_manager import NotesManager
from search_manager import SearchManager
from reminder_manager import ReminderManager
from analytics import AnalyticsManager
from export_manager import ExportManager
from import_manager import ImportManager
from validation import VALID_CATEGORIES, VALID_PRIORITIES, VALID_STATUSES


def clear_banner():
    print("\n" + "=" * 50)
    print("           PERSONAL NOTES ORGANIZER")
    print("     Welcome to your productivity workspace!")
    print("=" * 50)


def print_notes_table(notes):
    if not notes:
        print("\n[!] No notes found.")
        return

    print("\n" + "-" * 88)
    print(f"{'ID':<10} | {'Category':<11} | {'Priority':<8} | {'Status':<12} | {'Deadline':<11} | {'Title'}")
    print("-" * 88)
    for n in notes:
        nid = n.get("id", "N/A")
        cat = n.get("category", "General")[:10]
        prio = n.get("priority", "Med")[:7]
        stat = n.get("status", "Pending")[:11]
        deadline = n.get("deadline") or "---"
        title = n.get("title", "Untitled")
        if len(title) > 30:
            title = title[:27] + "..."
        print(f"{nid:<10} | {cat:<11} | {prio:<8} | {stat:<12} | {deadline:<11} | {title}")
    print("-" * 88)
    print(f"Total: {len(notes)} note(s)")


def view_single_note(manager: NotesManager):
    note_id = input("\nEnter Note ID (e.g. NOTE-001): ").strip().upper()
    note = manager.get_note_by_id(note_id)
    if not note:
        print(f"[X] Note '{note_id}' not found.")
        return

    rem = ReminderManager.evaluate_note(note)
    print("\n" + "=" * 60)
    print(f"Title:    {note.get('title')}")
    print(f"ID:       {note.get('id')}  |  Category: {note.get('category')}  |  Priority: {note.get('priority')}")
    print(f"Status:   {note.get('status')}  |  Deadline: {note.get('deadline') or 'None'} ({rem['label']})")
    tags = ", ".join([f"#{t}" for t in note.get("tags", [])]) or "None"
    print(f"Tags:     {tags}")
    print(f"Created:  {note.get('created_at')}  |  Updated: {note.get('updated_at')}")
    print("-" * 60)
    print("Content:\n")
    print(note.get("content"))
    print("=" * 60)


def create_note_cli(manager: NotesManager):
    print("\n--- Create New Note ---")
    title = input("Enter Title: ").strip()
    if not title:
        print("[X] Title cannot be empty.")
        return

    print("Enter Content (type EOF or empty line + Enter on blank line to finish):")
    lines = []
    while True:
        try:
            line = input()
            if line.strip() == "EOF" or (not line and lines):
                break
            lines.append(line)
        except EOFError:
            break
    content = "\n".join(lines).strip()
    if not content:
        print("[X] Content cannot be empty.")
        return

    print(f"\nAvailable Categories: {', '.join(manager.get_categories())}")
    category = input("Category (press Enter for 'Personal'): ").strip() or "Personal"

    tags_input = input("Tags (comma separated, e.g. college, study, exam): ").strip()

    print("Priority options: Low, Medium, High")
    priority = input("Priority (press Enter for 'Medium'): ").strip().capitalize() or "Medium"

    deadline = input("Deadline (YYYY-MM-DD, press Enter for None): ").strip() or None

    try:
        new_note = manager.create_note(
            title=title,
            content=content,
            category=category,
            tags=tags_input,
            deadline=deadline,
            priority=priority,
            status="Pending"
        )
        print(f"\n[+] Note created successfully with ID: {new_note['id']}")
    except ValueError as e:
        print(f"\n[X] Error creating note: {e}")


def search_notes_cli(manager: NotesManager):
    print("\n--- Search & Filter Notes ---")
    query = input("Search keyword (or press Enter): ").strip()
    category = input("Filter by Category (or press Enter for all): ").strip()
    tag = input("Filter by Tag (or press Enter for all): ").strip()
    priority = input("Filter by Priority (Low/Medium/High or press Enter): ").strip()
    status = input("Filter by Status (Pending/In Progress/Completed or press Enter): ").strip()

    results = SearchManager.composite_search(
        notes=manager.notes,
        query=query,
        category=category,
        tag=tag,
        priority=priority,
        status=status
    )
    print_notes_table(results)


def manage_tags_cli(manager: NotesManager):
    print("\n--- Manage & Browse Tags ---")
    tags = manager.get_all_tags()
    if not tags:
        print("No tags defined yet.")
        return

    print(f"Total Unique Tags: {len(tags)}")
    for idx, t in enumerate(tags, 1):
        matching = SearchManager.filter_by_tag(manager.notes, t)
        print(f"  {idx}. #{t:<18} ({len(matching)} note{'s' if len(matching) != 1 else ''})")

    choice = input("\nEnter tag name to view notes (or press Enter to return): ").strip()
    if choice:
        matched = SearchManager.filter_by_tag(manager.notes, choice)
        print_notes_table(matched)


def edit_note_cli(manager: NotesManager):
    note_id = input("\nEnter Note ID to edit (e.g. NOTE-001): ").strip().upper()
    note = manager.get_note_by_id(note_id)
    if not note:
        print(f"[X] Note '{note_id}' not found.")
        return

    print(f"\nEditing '{note['title']}' ({note_id})")
    print("(Press Enter on any field to keep existing value)\n")

    new_title = input(f"New Title [{note['title']}]: ").strip()
    new_cat = input(f"New Category [{note['category']}]: ").strip()
    existing_tags = ", ".join(note.get("tags", []))
    new_tags = input(f"New Tags [{existing_tags}]: ").strip()
    new_prio = input(f"New Priority [{note['priority']}]: ").strip()
    new_status = input(f"New Status [{note['status']}]: ").strip()
    existing_dl = note.get("deadline") or "None"
    new_dl = input(f"New Deadline [{existing_dl}]: ").strip()

    change_content = input("Update note content? (y/N): ").strip().lower()
    new_content = None
    if change_content == "y":
        print("Enter new content (type EOF or empty line + Enter on blank line to finish):")
        lines = []
        while True:
            try:
                line = input()
                if line.strip() == "EOF" or (not line and lines):
                    break
                lines.append(line)
            except EOFError:
                break
        new_content = "\n".join(lines).strip()

    try:
        manager.update_note(
            note_id=note_id,
            title=new_title if new_title else None,
            category=new_cat if new_cat else None,
            tags=new_tags if new_tags else None,
            priority=new_prio if new_prio else None,
            status=new_status if new_status else None,
            deadline=new_dl if new_dl and new_dl.lower() != "none" else (None if new_dl.lower() == "none" else None),
            content=new_content if new_content else None
        )
        print(f"\n[+] Note {note_id} updated successfully!")
    except Exception as e:
        print(f"\n[X] Update failed: {e}")


def delete_note_cli(manager: NotesManager):
    note_id = input("\nEnter Note ID to delete (e.g. NOTE-001): ").strip().upper()
    note = manager.get_note_by_id(note_id)
    if not note:
        print(f"[X] Note '{note_id}' not found.")
        return

    confirm = input(f"Are you sure you want to delete '{note['title']}'? (yes/NO): ").strip().lower()
    if confirm in ("yes", "y"):
        if manager.delete_note(note_id):
            print(f"[+] Note {note_id} deleted successfully.")
        else:
            print("[X] Failed to delete note.")
    else:
        print("Deletion cancelled.")


def export_notes_cli(manager: NotesManager):
    print("\n--- Export Reports ---")
    print("1. Export to CSV")
    print("2. Export to Formatted Text (TXT)")
    print("3. Export to Markdown (MD)")
    print("4. Export to ALL formats")
    choice = input("Select format (1-4): ").strip()

    notes = manager.notes
    if not notes:
        print("[!] No notes to export.")
        return

    if choice == "1":
        path = ExportManager.export_to_csv(notes)
        print(f"[+] Successfully exported CSV to:\n    {path}")
    elif choice == "2":
        path = ExportManager.export_to_txt(notes)
        print(f"[+] Successfully exported TXT to:\n    {path}")
    elif choice == "3":
        path = ExportManager.export_to_markdown(notes)
        print(f"[+] Successfully exported Markdown to:\n    {path}")
    elif choice == "4":
        p1 = ExportManager.export_to_csv(notes)
        p2 = ExportManager.export_to_txt(notes)
        p3 = ExportManager.export_to_markdown(notes)
        print("[+] Successfully exported all formats:")
        print(f"    • CSV:  {p1}")
        print(f"    • TXT:  {p2}")
        print(f"    • MD:   {p3}")
    else:
        print("[!] Invalid export option.")


def import_notes_cli(manager: NotesManager):
    print("\n--- Bulk CSV Import ---")
    default_sample = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample_data", "sample_notes.csv")
    print(f"Default sample file: {default_sample}")
    filepath = input("Enter CSV path (press Enter for sample file): ").strip() or default_sample

    res = ImportManager.import_from_csv(filepath, manager, skip_duplicate_titles=True)
    if res["success"]:
        print(f"\n[+] Import Complete!")
        print(f"    • Total Rows Processed: {res['total_rows']}")
        print(f"    • Successfully Imported: {res['imported']}")
        print(f"    • Skipped (Duplicates/Invalid): {res['skipped']}")
        if res["errors"]:
            print(f"    • Notices ({len(res['errors'])}):")
            for err in res["errors"][:5]:
                print(f"      - {err}")
    else:
        print(f"\n[X] Import failed: {', '.join(res['errors'])}")


def reminders_cli(manager: NotesManager):
    print("\n--- Deadlines & Reminders ---")
    summary = ReminderManager.get_reminders_summary(manager.notes)

    if summary["overdue_notes"]:
        print("\n[!] OVERDUE NOTES (Immediate Action Required):")
        for n in summary["overdue_notes"]:
            print(f"    • [{n['id']}] {n['title']} (Due: {n['deadline']} - {n['reminder_info']['label']})")

    if summary["due_today_notes"]:
        print("\n[*] DUE TODAY:")
        for n in summary["due_today_notes"]:
            print(f"    • [{n['id']}] {n['title']} (Due: {n['deadline']})")

    if summary["upcoming_notes"]:
        print("\n[>] UPCOMING IN NEXT 7 DAYS:")
        for n in summary["upcoming_notes"]:
            print(f"    • [{n['id']}] {n['title']} (Due: {n['deadline']} - {n['reminder_info']['label']})")

    if not summary["overdue_notes"] and not summary["due_today_notes"] and not summary["upcoming_notes"]:
        print("All caught up! No urgent or upcoming deadlines.")


def launch_gui():
    try:
        from gui import launch_gui_app
        launch_gui_app()
    except Exception as e:
        print(f"\n[X] Could not launch GUI: {e}")
        import traceback
        traceback.print_exc()


def launch_streamlit():
    try:
        import subprocess
        app_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "streamlit_app.py")
        print("\n[+] Launching Streamlit Web App...")
        print(f"    Target: {app_path}")
        print("    Press Ctrl+C in this terminal to stop the web server.\n")
        subprocess.run([sys.executable, "-m", "streamlit", "run", app_path])
    except Exception as e:
        print(f"\n[X] Could not launch Streamlit: {e}")


def main():
    clear_banner()
    print("Application initialized successfully!")
    print("Storage: Local JSON Database (Safe atomic write & auto-backups)")

    manager = NotesManager()

    # If --gui argument provided, start Tkinter GUI directly
    if "--gui" in sys.argv:
        launch_gui()
        return

    # If --streamlit argument provided, start Streamlit directly
    if "--streamlit" in sys.argv or "--web" in sys.argv:
        launch_streamlit()
        return

    while True:
        print("\n" + "=" * 50)
        print(" MAIN MENU - PERSONAL NOTES ORGANIZER")
        print("=" * 50)
        print("  1.  📝 Create Note")
        print("  2.  📋 View All Notes")
        print("  3.  🔍 Search & Filter Notes")
        print("  4.  🏷️  Manage Tags")
        print("  5.  📖 View Single Note Details")
        print("  6.  ✏️  Edit Note")
        print("  7.  🗑️  Delete Note")
        print("  8.  📊 Analytics Dashboard")
        print("  9.  ⏰ Deadlines & Reminders")
        print("  10. 📤 Export Reports (CSV / TXT / MD)")
        print("  11. 📥 Import Notes (Bulk CSV)")
        print("  12. 🖥️  Launch Graphical Desktop GUI (Tkinter)")
        print("  13. 🌐 Launch Modern Web App (Streamlit)")
        print("  0.  🚪 Exit")
        print("=" * 50)

        choice = input("Enter choice (0-13): ").strip()

        if choice == "1":
            create_note_cli(manager)
        elif choice == "2":
            print_notes_table(manager.get_all_notes())
        elif choice == "3":
            search_notes_cli(manager)
        elif choice == "4":
            manage_tags_cli(manager)
        elif choice == "5":
            view_single_note(manager)
        elif choice == "6":
            edit_note_cli(manager)
        elif choice == "7":
            delete_note_cli(manager)
        elif choice == "8":
            print(AnalyticsManager.generate_ascii_dashboard(manager.notes))
        elif choice == "9":
            reminders_cli(manager)
        elif choice == "10":
            export_notes_cli(manager)
        elif choice == "11":
            import_notes_cli(manager)
        elif choice == "12":
            print("\nLaunching Graphical Interface...")
            launch_gui()
        elif choice == "13":
            launch_streamlit()
        elif choice == "0":
            print("\nThank you for using Personal Notes Organizer. Goodbye!\n")
            sys.exit(0)
        else:
            print("[!] Invalid option. Please enter a number between 0 and 13.")


if __name__ == "__main__":
    main()
