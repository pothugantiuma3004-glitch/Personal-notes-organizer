"""
Quick launcher from the workspace root directory.
Runs Personal Notes Organizer directly.
"""
import os
import sys

project_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "PersonalNotesOrganizer")
sys.path.insert(0, project_dir)
os.chdir(project_dir)

if __name__ == "__main__":
    from main import main
    main()
