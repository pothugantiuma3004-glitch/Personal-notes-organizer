"""
notes_manager.py - Core Notes Management Engine
Provides full CRUD capabilities, category and tag resolution, unique ID generation,
and synchronization with the persistent storage layer.
"""

from datetime import datetime
from typing import List, Dict, Any, Optional

from storage import load_notes, save_notes, DEFAULT_NOTES_FILE, DEFAULT_BACKUP_FILE
from validation import (
    validate_note_payload,
    validate_title,
    validate_content,
    validate_category,
    validate_priority,
    validate_status,
    validate_date,
    sanitize_tags,
    VALID_CATEGORIES,
    VALID_PRIORITIES,
    VALID_STATUSES
)


class NotesManager:
    """Manages notes lifecycle: Create, Read, Update, Delete, and Query."""

    def __init__(self,
                 filepath: str = DEFAULT_NOTES_FILE,
                 backup_path: str = DEFAULT_BACKUP_FILE):
        self.filepath = filepath
        self.backup_path = backup_path
        self.notes: List[Dict[str, Any]] = []
        self.reload()

    def reload(self) -> None:
        """Reload notes from disk storage."""
        self.notes = load_notes(self.filepath, self.backup_path)

    def save(self) -> bool:
        """Persist current in-memory notes to disk."""
        return save_notes(self.notes, self.filepath, self.backup_path)

    def generate_next_id(self) -> str:
        """Generates the next sequential unique ID like 'NOTE-001'."""
        max_id = 0
        for note in self.notes:
            nid = str(note.get("id", ""))
            if nid.startswith("NOTE-"):
                num_part = nid.replace("NOTE-", "")
                if num_part.isdigit():
                    max_id = max(max_id, int(num_part))
        return f"NOTE-{max_id + 1:03d}"

    def create_note(self,
                    title: str,
                    content: str,
                    category: str = "Personal",
                    tags: Any = None,
                    deadline: Optional[str] = None,
                    priority: str = "Medium",
                    status: str = "Pending") -> Dict[str, Any]:
        """
        Creates a new note with validation, auto-generated ID, and timestamps.
        Raises ValueError if validation fails.
        """
        # Validate input fields
        payload = {
            "title": title,
            "content": content,
            "category": category,
            "priority": priority,
            "status": status,
            "deadline": deadline
        }
        is_valid, errors = validate_note_payload(payload)
        if not is_valid:
            raise ValueError("; ".join(errors))

        now_iso = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        clean_deadline = deadline.strip() if deadline and deadline.strip() else None

        new_note: Dict[str, Any] = {
            "id": self.generate_next_id(),
            "title": title.strip(),
            "content": content.strip(),
            "category": category.strip(),
            "tags": sanitize_tags(tags),
            "deadline": clean_deadline,
            "priority": priority.strip().capitalize(),
            "status": status.strip().title(),
            "created_at": now_iso,
            "updated_at": now_iso
        }

        self.notes.append(new_note)
        self.save()
        return new_note

    def get_all_notes(self, sort_by: str = "updated_at", reverse: bool = True) -> List[Dict[str, Any]]:
        """Returns all notes, sorted by given field."""
        def get_sort_val(note):
            val = note.get(sort_by, "")
            return "" if val is None else str(val)

        return sorted(self.notes, key=get_sort_val, reverse=reverse)

    def get_note_by_id(self, note_id: str) -> Optional[Dict[str, Any]]:
        """Finds a single note by its unique identifier."""
        clean_id = str(note_id).strip().upper()
        for note in self.notes:
            if str(note.get("id", "")).strip().upper() == clean_id:
                return note
        return None

    def update_note(self,
                    note_id: str,
                    title: Optional[str] = None,
                    content: Optional[str] = None,
                    category: Optional[str] = None,
                    tags: Any = None,
                    deadline: Optional[str] = None,
                    priority: Optional[str] = None,
                    status: Optional[str] = None) -> Dict[str, Any]:
        """
        Updates an existing note with new values and refreshes updated_at timestamp.
        Raises KeyError if note not found, or ValueError if invalid.
        """
        note = self.get_note_by_id(note_id)
        if not note:
            raise KeyError(f"Note with ID '{note_id}' does not exist.")

        # Validate updates
        if title is not None:
            ok, msg = validate_title(title)
            if not ok:
                raise ValueError(msg)
            note["title"] = title.strip()

        if content is not None:
            ok, msg = validate_content(content)
            if not ok:
                raise ValueError(msg)
            note["content"] = content.strip()

        if category is not None:
            ok, msg = validate_category(category)
            if not ok:
                raise ValueError(msg)
            note["category"] = category.strip()

        if tags is not None:
            note["tags"] = sanitize_tags(tags)

        if deadline is not None:
            ok, msg = validate_date(deadline)
            if not ok:
                raise ValueError(msg)
            note["deadline"] = deadline.strip() if deadline.strip() else None

        if priority is not None:
            ok, msg = validate_priority(priority)
            if not ok:
                raise ValueError(msg)
            note["priority"] = priority.strip().capitalize()

        if status is not None:
            ok, msg = validate_status(status)
            if not ok:
                raise ValueError(msg)
            note["status"] = status.strip().title()

        note["updated_at"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        self.save()
        return note

    def delete_note(self, note_id: str) -> bool:
        """Deletes a note by its ID. Returns True if deleted, False if not found."""
        target = self.get_note_by_id(note_id)
        if target:
            self.notes.remove(target)
            self.save()
            return True
        return False

    def get_categories(self) -> List[str]:
        """Returns standard categories plus any custom categories used in notes."""
        categories = set(VALID_CATEGORIES)
        for note in self.notes:
            cat = note.get("category")
            if cat:
                categories.add(cat)
        return sorted(list(categories))

    def get_all_tags(self) -> List[str]:
        """Returns a sorted list of all unique tags in the system."""
        tags = set()
        for note in self.notes:
            for tag in note.get("tags", []):
                tags.add(tag)
        return sorted(list(tags))
